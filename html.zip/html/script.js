// script.js

// Functionality to search for books
const searchInput = document.getElementById('searchInput');
const searchButton = document.getElementById('searchButton');
const bookReviews = document.getElementById('bookReviews');

searchButton.addEventListener('click', function() {
    const searchTerm = searchInput.value.toLowerCase();
    // Perform search functionality here
    console.log('Searching for:', searchTerm);

    // Simulated search results (replace with actual search logic)
    const foundBooks = []; // Array to hold found books (simulated)
    if (foundBooks.length === 0) {
        bookReviews.innerHTML = '<h2>Results of search</h2><p>Not found</p>';
    } else {
        // Display search results
        // Display search results
        let html = '<h2>Search Results</h2><ul>';
        foundBooks.forEach(book => {
            html += `<li>${book}</li>`;
        });
        html += '</ul>';
        bookReviews.innerHTML = html;
    }
});

// Functionality for date of birth
const dobInput = document.getElementById('dobInput');
dobInput.addEventListener('change', function() {
    const dob = this.value;
    console.log('Date of Birth:', dob);
});
